﻿namespace Com.LuisPedroFonseca.ProCamera2D
{
    public enum MovementAxis
    {
        XY,
        XZ,
        YZ
    }
}