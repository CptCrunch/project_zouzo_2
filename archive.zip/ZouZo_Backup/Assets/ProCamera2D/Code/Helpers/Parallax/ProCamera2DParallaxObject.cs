﻿using UnityEngine;

namespace Com.LuisPedroFonseca.ProCamera2D
{
    /// <summary>
    /// Add this class to an object if you want it's position on the scene view to match the same relative position to the main parallax layer during runtime.
    /// </summary>
    public class ProCamera2DParallaxObject : MonoBehaviour
    {
    
    }
}