using UnityEngine;
using System.Collections;

public class PatrolWaypoint : MonoBehaviour 
{
    public float StopProbability = .5f;
    public float StopDuration = 3f;
    public float StopDurationVariation = 2f;
}
